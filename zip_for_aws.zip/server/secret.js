
// systembolagets API
exports.Ocp_Apim_Subscription_Key = "269a31c61c6640dcaf4df2e618698595";
exports.duckdnsToken = "f7d096a3-3a4a-42d8-89f9-4a0aff20d63a";
